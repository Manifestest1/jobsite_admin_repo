import { useEffect } from 'react';
import { useHistory } from 'react-router-dom';

function RedirectToCleanUrl() {
  const history = useHistory();

  useEffect(() => {
    const currentPath = window.location.pathname;
    if (currentPath.startsWith('/en')) {
      const newPath = currentPath.replace('/en', '');
      history.replace(newPath);
    }
  }, [history]);

  return null;
}

export default RedirectToCleanUrl;
