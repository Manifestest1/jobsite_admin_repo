import instance from './axios';

export const UserLoginApi = (user) => {
  return instance.post('/login', user);
};

export const getUserProfile = () => {
    return instance.get('/user-profile');
  };

  export const getHostelList = () => {
    return instance.get('/hostel-list');
  };

  export const logoutUserProfile = () => {
    return instance.post('/logout');
  };
